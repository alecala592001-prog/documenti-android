# Verifica della consegna

## Controlli completati

- struttura completa del progetto Android;
- sintassi bilanciata dei file Kotlin;
- validità XML di manifest e risorse;
- integrità del Gradle Wrapper 8.9;
- sintassi dello script `gradlew`;
- anteprima interattiva verificata e JavaScript validato;
- presenza della home essenziale “Documenti”, ricerca, gestione cartelle e sincronizzazione automatica all’avvio;
- navigazione PDF a pagina intera, senza conflitto tra zoom e swipe, con pulsanti precedente/successiva;
- disponibilità delle coordinate Maven principali;
- assenza di segnaposto `TODO`, conflitti di merge e credenziali incorporate.

## Controllo da eseguire con Android SDK

L’ambiente in cui il progetto è stato generato non contiene Android SDK 35, emulatori o Android Studio e non può scaricare la distribuzione Gradle dalla rete esterna. Per questo motivo non è stato possibile eseguire qui `assembleDebug`, i test Android e l’installazione su un dispositivo reale.

Dopo aver aperto il progetto in Android Studio, eseguire:

```bash
./gradlew test lint assembleDebug
```

Prima di una distribuzione lavorativa, verificare inoltre la sincronizzazione con il provider cloud autorizzato dall’azienda e provare almeno un PDF, un PPTX e un allegato condiviso dall’app email effettivamente utilizzata.
