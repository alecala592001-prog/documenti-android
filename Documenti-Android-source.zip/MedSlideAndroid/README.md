# Documenti

Documenti è un archivio Android essenziale per slide e file destinati ai medici. È progettato per smartphone e tablet e mantiene i file privati: i documenti restano sul dispositivo e, se attivata, soltanto nella cartella cloud scelta dall’utente.

## Esperienza principale

- La home mostra soltanto il titolo **Documenti**, la ricerca, il comando **+** e le cartelle.
- Il comando **+** permette di creare, rinominare o eliminare le cartelle e di configurare la sincronizzazione.
- Un tocco sulla cartella apre subito l’ultimo documento consultato, oppure il primo presente. Non esiste una schermata intermedia obbligatoria.
- I PDF e le immagini si visualizzano dentro Documenti.
- Le pagine PDF si scorrono orizzontalmente usando tutta la superficie della slide; sono disponibili anche due frecce laterali.
- PowerPoint e Word si aprono direttamente nell’app compatibile installata sul dispositivo.
- Il pulsante “Documenti” nel visualizzatore apre l’elenco soltanto quando serve gestire, rinominare o cambiare file.

## Funzioni incluse

- Cartelle creabili, rinominabili, colorabili ed eliminabili.
- Importazione dal selettore Android.
- Ricezione di uno o più allegati tramite **Condividi** e **Apri con** dalle app email.
- PDF, PPT, PPTX, DOC, DOCX, JPG, PNG e WebP.
- Rilevamento dei duplicati tramite SHA-256.
- Preferiti, rinomina ed eliminazione dei documenti.
- Memorizzazione dell’ultima cartella, dell’ultimo documento e dell’ultima pagina PDF.
- Layout adattivo: griglia su telefono e pannello documenti laterale su tablet.
- Tema chiaro e scuro.
- Archivio locale offline basato su Room.
- Sincronizzazione tramite una cartella scelta con il selettore di sistema.

## Sincronizzazione telefono–tablet

La sincronizzazione non richiede un server proprietario né credenziali inserite nell’app.

1. Installa e accedi a Google Drive, OneDrive o al provider cloud autorizzato dall’azienda.
2. In Documenti tocca **+**, poi **Sincronizzazione**.
3. Scegli una cartella cloud, per esempio `Documenti personale`.
4. Sul secondo dispositivo scegli esattamente la stessa cartella.

Documenti crea al suo interno `Documenti Sync`, con un manifesto e le copie dei documenti. Dopo la configurazione iniziale, modifiche e nuovi file vengono sincronizzati automaticamente e periodicamente tramite WorkManager. Il selettore Android conserva l’autorizzazione senza concedere all’app accesso indiscriminato al resto dello spazio cloud.

> Per documenti aziendali o sanitari, usa esclusivamente un account e un provider approvati dal datore di lavoro.

## Apertura dei formati

| Formato | Comportamento |
| --- | --- |
| PDF | Visualizzatore interno, swipe a pagina intera, frecce laterali, ultima pagina |
| JPG/PNG/WebP | Visualizzatore interno con zoom |
| PPT/PPTX | Apertura immediata con PowerPoint, Microsoft 365, Google Slides o altra app compatibile |
| DOC/DOCX | Apertura immediata con Word, Microsoft 365 o altra app compatibile |

Android non offre un renderer PowerPoint nativo affidabile. Documenti evita conversioni online automatiche per non inviare documenti riservati a servizi esterni.

## Compilazione

Requisiti:

- Android Studio Ladybug o più recente;
- JDK 17;
- Android SDK 35.

Apri la cartella `MedSlideAndroid` in Android Studio, attendi la sincronizzazione Gradle e avvia la configurazione `app`.

Da terminale:

```bash
./gradlew test lint assembleDebug
```

L’APK debug viene generato in:

```text
app/build/outputs/apk/debug/app-debug.apk
```

### Compilazione online

Il progetto include il flusso GitHub Actions `Build Documenti APK`. A ogni caricamento sul ramo `main`, oppure avviandolo manualmente, compila e rende disponibile l’artefatto installabile `Documenti.apk`.

## Struttura

- `data/`: database Room, modelli, importazione e archivio locale.
- `sync/`: cartella cloud, manifesto, merge e WorkManager.
- `ui/`: home, visualizzatore, dialoghi e stato applicativo.
- `ui/theme/`: palette e tipografia dell’app.

## Limiti intenzionali della versione 1.1.1

- PPTX e DOCX richiedono un’app compatibile installata.
- La sincronizzazione in background dipende dal provider cloud scelto e dalle limitazioni energetiche del dispositivo.
- Se due dispositivi modificano esattamente lo stesso elemento prima di sincronizzarsi, prevale la modifica più recente.
- La build di release deve essere firmata con il keystore del proprietario prima della distribuzione.
