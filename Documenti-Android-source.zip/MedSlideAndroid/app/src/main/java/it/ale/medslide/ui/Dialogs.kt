package it.ale.medslide.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloudDone
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import it.ale.medslide.data.FolderEntity

@Composable
fun ImportDestinationDialog(
    fileCount: Int,
    folders: List<FolderEntity>,
    onFolderSelected: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (fileCount == 1) "Dove vuoi salvarlo?" else "Dove vuoi salvarli?") },
        text = {
            Column {
                Text(
                    text = if (fileCount == 1) "Scegli la cartella. Il documento si aprirà subito." else "$fileCount documenti selezionati",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(16.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(folders, key = { it.id }) { folder ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onFolderSelected(folder.id) }
                                .background(
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                    RoundedCornerShape(14.dp),
                                )
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Folder,
                                contentDescription = null,
                                tint = Color(folder.color),
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(folder.name, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SyncSheet(
    configured: Boolean,
    state: SyncUiState,
    onChooseFolder: () -> Unit,
    onSyncNow: () -> Unit,
    onDisconnect: () -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 36.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = if (configured) Icons.Outlined.CloudDone else Icons.Outlined.CloudOff,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("Sincronizzazione", style = MaterialTheme.typography.titleLarge)
                    Text(
                        if (configured) "Cartella cloud collegata" else "Non ancora configurata",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(22.dp))
            Text(
                "Scegli la stessa cartella Google Drive o OneDrive sul telefono e sul tablet. Documenti terrà allineati automaticamente file e nomi.",
                style = MaterialTheme.typography.bodyLarge,
            )
            Spacer(Modifier.height(20.dp))
            when (state) {
                SyncUiState.Idle -> Unit
                SyncUiState.Running -> Text("Sincronizzazione in corso…", color = MaterialTheme.colorScheme.primary)
                is SyncUiState.Complete -> {
                    val report = state.report
                    Text(
                        "Completata · ${report.uploaded} caricati · ${report.downloaded} scaricati",
                        color = if (report.errors.isEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    )
                }
                is SyncUiState.Failed -> Text(state.message, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(20.dp))
            Button(onClick = onChooseFolder, modifier = Modifier.fillMaxWidth()) {
                Text(if (configured) "Cambia cartella cloud" else "Scegli cartella cloud")
            }
            if (configured) {
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = onSyncNow, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.Sync, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Sincronizza ora")
                }
                Spacer(Modifier.height(18.dp))
                HorizontalDivider()
                TextButton(onClick = onDisconnect, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text("Scollega questa cartella", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}
