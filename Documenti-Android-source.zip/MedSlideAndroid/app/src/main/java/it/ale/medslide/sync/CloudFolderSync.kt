package it.ale.medslide.sync

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import it.ale.medslide.data.DocumentEntity
import it.ale.medslide.data.FileNameSanitizer
import it.ale.medslide.data.FolderEntity
import it.ale.medslide.data.MedSlideDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

data class SyncReport(
    val uploaded: Int = 0,
    val downloaded: Int = 0,
    val metadataMerged: Int = 0,
    val errors: List<String> = emptyList(),
)

class CloudFolderSync(
    private val context: Context,
    private val dao: MedSlideDao,
    private val settings: SyncSettings,
) {
    suspend fun sync(): SyncReport = withContext(Dispatchers.IO) {
        val treeUri = settings.treeUri.first()
            ?: return@withContext SyncReport(errors = listOf("Scegli una cartella cloud nelle impostazioni"))
        val selectedRoot = DocumentFile.fromTreeUri(context, treeUri)
            ?: return@withContext SyncReport(errors = listOf("La cartella cloud non è più disponibile"))
        if (!selectedRoot.canRead() || !selectedRoot.canWrite()) {
            return@withContext SyncReport(errors = listOf("La cartella cloud non concede accesso in lettura e scrittura"))
        }

        val syncRoot = selectedRoot.findFile(SYNC_DIRECTORY)
            ?: selectedRoot.createDirectory(SYNC_DIRECTORY)
            ?: return@withContext SyncReport(errors = listOf("Impossibile creare la cartella Documenti Sync"))
        val blobDirectory = syncRoot.findFile(BLOB_DIRECTORY)
            ?: syncRoot.createDirectory(BLOB_DIRECTORY)
            ?: return@withContext SyncReport(errors = listOf("Impossibile creare la cartella dei documenti"))

        val manifestFile = syncRoot.findFile(MANIFEST_FILE)
        val remoteManifest = manifestFile?.let(::readManifest) ?: Manifest(emptyList(), emptyList())
        val localFolders = dao.getAllFoldersIncludingDeleted()
        val localDocuments = dao.getAllDocumentsIncludingDeleted()

        val mergedFolders = mergeFolders(localFolders, remoteManifest.folders)
        val folderUpdates = mergedFolders.filter { merged ->
            localFolders.firstOrNull { it.id == merged.id } != merged
        }
        if (folderUpdates.isNotEmpty()) dao.upsertFolders(folderUpdates)

        val localById = localDocuments.associateBy { it.id }
        val remoteById = remoteManifest.documents.associateBy { it.id }
        val allDocumentIds = (localById.keys + remoteById.keys).distinct()
        val finalDocuments = mutableListOf<DocumentEntity>()
        val errors = mutableListOf<String>()
        var uploaded = 0
        var downloaded = 0
        var mergedCount = folderUpdates.size

        allDocumentIds.forEach { id ->
            val local = localById[id]
            val remote = remoteById[id]
            val winner = when {
                local == null -> remote
                remote == null -> local
                local.updatedAt >= remote.updatedAt -> local
                else -> remote
            } ?: return@forEach

            if (winner.deletedAt != null) {
                val tombstone = winner.copy(localPath = local?.localPath.orEmpty())
                finalDocuments += tombstone
                if (local != tombstone) mergedCount++
                return@forEach
            }

            val localFile = local?.localPath?.takeIf { it.isNotBlank() }?.let(::File)
            val localWins = local != null && (remote == null || local.updatedAt >= remote.updatedAt)

            if (localWins && localFile?.exists() == true) {
                val uploadedName = uploadBlob(blobDirectory, local, localFile)
                if (uploadedName != null) {
                    finalDocuments += local.copy(remoteFileName = uploadedName)
                    if (remote == null || remote.updatedAt < local.updatedAt || remote.remoteFileName != uploadedName) uploaded++
                } else {
                    finalDocuments += local
                    errors += "Caricamento non riuscito: ${local.displayName}"
                }
            } else {
                val remoteName = remote?.remoteFileName
                val remoteBlob = remoteName?.let(blobDirectory::findFile)
                if (remote != null && remoteBlob != null) {
                    val extension = FileNameSanitizer.extensionOf(remote.displayName)
                    val destinationDir = File(context.filesDir, "documents").apply { mkdirs() }
                    val destination = File(
                        destinationDir,
                        if (extension.isBlank()) remote.id else "${remote.id}.$extension",
                    )
                    val copied = runCatching {
                        context.contentResolver.openInputStream(remoteBlob.uri)?.use { input ->
                            FileOutputStream(destination).use { output -> input.copyTo(output) }
                        } ?: error("File cloud illeggibile")
                    }.isSuccess
                    if (copied) {
                        finalDocuments += remote.copy(
                            localPath = destination.absolutePath,
                            sizeBytes = destination.length(),
                            lastPage = local?.lastPage ?: remote.lastPage,
                        )
                        downloaded++
                        mergedCount++
                    } else {
                        errors += "Download non riuscito: ${remote.displayName}"
                        if (local != null) finalDocuments += local
                    }
                } else if (local != null) {
                    finalDocuments += local
                    errors += "Copia cloud mancante: ${local.displayName}"
                }
            }
        }

        if (finalDocuments.isNotEmpty()) dao.upsertDocuments(finalDocuments)
        writeManifest(syncRoot, Manifest(mergedFolders, finalDocuments))

        SyncReport(
            uploaded = uploaded,
            downloaded = downloaded,
            metadataMerged = mergedCount,
            errors = errors,
        )
    }

    private fun mergeFolders(local: List<FolderEntity>, remote: List<FolderEntity>): List<FolderEntity> {
        val localById = local.associateBy { it.id }
        val remoteById = remote.associateBy { it.id }
        return (localById.keys + remoteById.keys).distinct().mapNotNull { id ->
            val localFolder = localById[id]
            val remoteFolder = remoteById[id]
            when {
                localFolder == null -> remoteFolder
                remoteFolder == null -> localFolder
                localFolder.updatedAt >= remoteFolder.updatedAt -> localFolder
                else -> remoteFolder.copy(lastOpenedDocumentId = localFolder.lastOpenedDocumentId)
            }
        }
    }

    private fun uploadBlob(directory: DocumentFile, document: DocumentEntity, source: File): String? {
        val requestedName = document.remoteFileName
            ?: FileNameSanitizer.withStablePrefix(document.id, document.displayName)
        val existing = directory.findFile(requestedName)
        val target = existing ?: directory.createFile(document.mimeType, requestedName) ?: return null
        return runCatching {
            context.contentResolver.openOutputStream(target.uri, "wt")?.use { output ->
                source.inputStream().use { input -> input.copyTo(output) }
            } ?: error("Destinazione cloud non scrivibile")
            target.name ?: requestedName
        }.getOrNull()
    }

    private fun readManifest(file: DocumentFile): Manifest? = runCatching {
        val text = context.contentResolver.openInputStream(file.uri)
            ?.bufferedReader()
            ?.use { it.readText() }
            ?: return null
        val root = JSONObject(text)
        val folders = root.optJSONArray("folders").toFolders()
        val documents = root.optJSONArray("documents").toDocuments()
        Manifest(folders, documents)
    }.getOrNull()

    private fun writeManifest(root: DocumentFile, manifest: Manifest) {
        val existing = root.findFile(MANIFEST_FILE)
        val file = existing ?: root.createFile("application/json", MANIFEST_FILE) ?: return
        val json = JSONObject().apply {
            put("schemaVersion", 1)
            put("generatedAt", System.currentTimeMillis())
            put("folders", JSONArray().apply { manifest.folders.forEach { put(it.toJson()) } })
            put("documents", JSONArray().apply { manifest.documents.forEach { put(it.toJson()) } })
        }
        runCatching {
            context.contentResolver.openOutputStream(file.uri, "wt")
                ?.bufferedWriter()
                ?.use { it.write(json.toString()) }
        }
    }

    private data class Manifest(
        val folders: List<FolderEntity>,
        val documents: List<DocumentEntity>,
    )

    companion object {
        private const val SYNC_DIRECTORY = "Documenti Sync"
        private const val BLOB_DIRECTORY = "Documenti"
        private const val MANIFEST_FILE = "medslide-manifest.json"
    }
}

private fun FolderEntity.toJson(): JSONObject = JSONObject().apply {
    put("id", id)
    put("name", name)
    put("color", color)
    put("sortIndex", sortIndex)
    put("updatedAt", updatedAt)
    put("deletedAt", deletedAt ?: JSONObject.NULL)
}

private fun DocumentEntity.toJson(): JSONObject = JSONObject().apply {
    put("id", id)
    put("folderId", folderId)
    put("displayName", displayName)
    put("mimeType", mimeType)
    put("sizeBytes", sizeBytes)
    put("sha256", sha256)
    put("sortIndex", sortIndex)
    put("createdAt", createdAt)
    put("updatedAt", updatedAt)
    put("deletedAt", deletedAt ?: JSONObject.NULL)
    put("isFavorite", isFavorite)
    put("lastPage", lastPage)
    put("remoteFileName", remoteFileName ?: JSONObject.NULL)
}

private fun JSONArray?.toFolders(): List<FolderEntity> {
    if (this == null) return emptyList()
    return buildList {
        for (index in 0 until length()) {
            val item = optJSONObject(index) ?: continue
            add(
                FolderEntity(
                    id = item.getString("id"),
                    name = item.optString("name", "Cartella"),
                    color = item.optLong("color", 0xFF2D716CL),
                    sortIndex = item.optInt("sortIndex", index),
                    updatedAt = item.optLong("updatedAt", 0L),
                    deletedAt = item.nullableLong("deletedAt"),
                    lastOpenedDocumentId = null,
                ),
            )
        }
    }
}

private fun JSONArray?.toDocuments(): List<DocumentEntity> {
    if (this == null) return emptyList()
    return buildList {
        for (index in 0 until length()) {
            val item = optJSONObject(index) ?: continue
            add(
                DocumentEntity(
                    id = item.getString("id"),
                    folderId = item.getString("folderId"),
                    displayName = item.optString("displayName", "Documento"),
                    mimeType = item.optString("mimeType", "application/octet-stream"),
                    localPath = "",
                    sizeBytes = item.optLong("sizeBytes", 0L),
                    sha256 = item.optString("sha256", ""),
                    sortIndex = item.optInt("sortIndex", index),
                    createdAt = item.optLong("createdAt", 0L),
                    updatedAt = item.optLong("updatedAt", 0L),
                    deletedAt = item.nullableLong("deletedAt"),
                    isFavorite = item.optBoolean("isFavorite", false),
                    lastPage = item.optInt("lastPage", 0),
                    remoteFileName = item.nullableString("remoteFileName"),
                ),
            )
        }
    }
}

private fun JSONObject.nullableLong(key: String): Long? =
    if (!has(key) || isNull(key)) null else optLong(key)

private fun JSONObject.nullableString(key: String): String? =
    if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() }
