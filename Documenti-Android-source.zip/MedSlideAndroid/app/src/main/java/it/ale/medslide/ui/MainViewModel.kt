package it.ale.medslide.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import it.ale.medslide.MedSlideApplication
import it.ale.medslide.data.DocumentEntity
import it.ale.medslide.data.FolderEntity
import it.ale.medslide.data.FolderWithCount
import it.ale.medslide.sync.SyncReport
import it.ale.medslide.sync.SyncScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface SyncUiState {
    data object Idle : SyncUiState
    data object Running : SyncUiState
    data class Complete(val report: SyncReport) : SyncUiState
    data class Failed(val message: String) : SyncUiState
}

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as MedSlideApplication
    private val repository = app.container.repository
    private val syncSettings = app.container.syncSettings

    val folders: StateFlow<List<FolderWithCount>> = repository.foldersWithCount.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList(),
    )

    val folderEntities: StateFlow<List<FolderEntity>> = repository.folders.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList(),
    )

    private val selectedFolderId = MutableStateFlow<String?>(null)
    private val selectedDocumentId = MutableStateFlow<String?>(null)

    val currentFolder: StateFlow<FolderEntity?> = combine(
        selectedFolderId,
        folderEntities,
    ) { id, all -> all.firstOrNull { it.id == id } }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        null,
    )

    val documents: StateFlow<List<DocumentEntity>> = selectedFolderId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.documents(id)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList(),
    )

    val currentDocument: StateFlow<DocumentEntity?> = combine(
        documents,
        selectedDocumentId,
    ) { all, selectedId ->
        all.firstOrNull { it.id == selectedId } ?: all.firstOrNull()
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        null,
    )

    val syncTreeUri: StateFlow<Uri?> = syncSettings.treeUri.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        null,
    )

    private val _pendingImports = MutableStateFlow<List<Uri>>(emptyList())
    val pendingImports: StateFlow<List<Uri>> = _pendingImports

    private val _syncState = MutableStateFlow<SyncUiState>(SyncUiState.Idle)
    val syncState: StateFlow<SyncUiState> = _syncState

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages = _messages.asSharedFlow()

    fun queueImports(uris: List<Uri>) {
        if (uris.isNotEmpty()) _pendingImports.value = uris.distinct()
    }

    fun clearPendingImports() {
        _pendingImports.value = emptyList()
    }

    fun openFolder(folderId: String) {
        viewModelScope.launch {
            val folder = repository.getFolder(folderId) ?: return@launch
            val all = repository.activeDocuments(folderId)
            val preferred = all.firstOrNull { it.id == folder.lastOpenedDocumentId } ?: all.firstOrNull()
            selectedFolderId.value = folderId
            selectedDocumentId.value = preferred?.id
            preferred?.let { repository.rememberOpened(folderId, it.id) }
        }
    }

    fun closeFolder() {
        selectedFolderId.value = null
        selectedDocumentId.value = null
    }

    fun selectDocument(document: DocumentEntity) {
        selectedDocumentId.value = document.id
        viewModelScope.launch { repository.rememberOpened(document.folderId, document.id) }
    }

    fun createFolder(name: String, color: Long, openAfterCreate: Boolean = false) {
        viewModelScope.launch {
            val folder = repository.createFolder(name, color)
            if (openAfterCreate) openFolder(folder.id)
            requestBackgroundSync()
        }
    }

    fun renameFolder(id: String, name: String) {
        viewModelScope.launch {
            repository.renameFolder(id, name)
            requestBackgroundSync()
        }
    }

    fun recolorFolder(id: String, color: Long) {
        viewModelScope.launch {
            repository.recolorFolder(id, color)
            requestBackgroundSync()
        }
    }

    fun deleteFolder(id: String) {
        viewModelScope.launch {
            repository.deleteFolder(id)
            if (selectedFolderId.value == id) closeFolder()
            requestBackgroundSync()
        }
    }

    fun importPendingInto(folderId: String) {
        val uris = _pendingImports.value
        if (uris.isEmpty()) return
        _pendingImports.value = emptyList()
        viewModelScope.launch {
            val result = repository.importUris(folderId, uris)
            when {
                result.imported.isNotEmpty() -> {
                    selectedFolderId.value = folderId
                    selectedDocumentId.value = result.imported.first().id
                    repository.rememberOpened(folderId, result.imported.first().id)
                    _messages.emit("${result.imported.size} file importati")
                }
                result.duplicates.isNotEmpty() -> _messages.emit("File già presente nell’archivio")
                else -> _messages.emit("Non è stato possibile importare il file")
            }
            if (result.failedNames.isNotEmpty()) {
                _messages.emit("Alcuni file non sono stati letti")
            }
            requestBackgroundSync()
        }
    }

    fun renameDocument(id: String, name: String) {
        viewModelScope.launch {
            repository.renameDocument(id, name)
            requestBackgroundSync()
        }
    }

    fun toggleFavorite(document: DocumentEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(document)
            requestBackgroundSync()
        }
    }

    fun deleteDocument(document: DocumentEntity) {
        viewModelScope.launch {
            repository.deleteDocument(document.id)
            selectedDocumentId.value = null
            requestBackgroundSync()
        }
    }

    fun rememberPage(documentId: String, page: Int) {
        viewModelScope.launch { repository.rememberPage(documentId, page) }
    }

    fun setSyncFolder(uri: Uri, permissionFlags: Int) {
        val resolver = getApplication<Application>().contentResolver
        runCatching {
            resolver.takePersistableUriPermission(
                uri,
                permissionFlags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION),
            )
        }
        viewModelScope.launch {
            syncSettings.setTreeUri(uri)
            syncNow()
        }
    }

    fun disconnectSync() {
        viewModelScope.launch {
            syncSettings.setTreeUri(null)
            _syncState.value = SyncUiState.Idle
        }
    }

    fun syncNow() {
        if (_syncState.value is SyncUiState.Running) return
        viewModelScope.launch {
            _syncState.value = SyncUiState.Running
            val result = runCatching {
                withContext(Dispatchers.IO) { app.container.sync.sync() }
            }
            _syncState.value = result.fold(
                onSuccess = { SyncUiState.Complete(it) },
                onFailure = { SyncUiState.Failed(it.message ?: "Sincronizzazione non riuscita") },
            )
        }
    }

    private fun requestBackgroundSync() {
        if (syncTreeUri.value != null) SyncScheduler.syncNow(getApplication())
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(application) as T
        }
    }
}
