package it.ale.medslide.ui

import android.net.Uri
import android.os.Bundle
import androidx.core.os.bundleOf
import androidx.pdf.ExperimentalPdfApi
import androidx.pdf.PdfDocument
import androidx.pdf.view.PdfView
import androidx.pdf.viewer.fragment.PdfViewerFragment

/**
 * PDF viewer with native pinch zoom, selectable text, copy menu and clickable links.
 * The small public surface keeps Compose controls independent from AndroidX PDF internals.
 */
class InteractivePdfFragment : PdfViewerFragment() {
    var onPageChanged: ((page: Int, pageCount: Int) -> Unit)? = null
    var onLoadFailed: ((Throwable) -> Unit)? = null

    private var interactiveView: PdfView? = null
    private var pageCount: Int = 0
    private var restoredPage: Int? = null

    @OptIn(ExperimentalPdfApi::class)
    override fun onPdfViewCreated(pdfView: PdfView) {
        interactiveView = pdfView
        pdfView.maxZoom = 10f
        pdfView.addOnViewportChangedListener(
            object : PdfView.OnViewportChangedListener {
                override fun onViewportChanged(
                    firstVisiblePage: Int,
                    visiblePagesCount: Int,
                    pageLocations: android.util.SparseArray<android.graphics.RectF>,
                    zoomLevel: Float,
                ) {
                    if (pageCount > 0) {
                        onPageChanged?.invoke(firstVisiblePage.coerceIn(0, pageCount - 1), pageCount)
                    }
                }
            }
        )
    }

    override fun onViewCreated(view: android.view.View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        restoredPage = savedInstanceState?.getInt("visible_page")
        arguments?.getString(ARG_URI)?.let { documentUri = Uri.parse(it) }
    }

    override fun onLoadDocumentSuccess(document: PdfDocument) {
        pageCount = document.pageCount
        val initialPage = restoredPage ?: arguments?.getInt(ARG_INITIAL_PAGE, 0) ?: 0
        interactiveView?.scrollToPage(initialPage.coerceIn(0, (pageCount - 1).coerceAtLeast(0)))
        onPageChanged?.invoke(initialPage.coerceIn(0, (pageCount - 1).coerceAtLeast(0)), pageCount)
    }

    override fun onLoadDocumentError(error: Throwable) {
        onLoadFailed?.invoke(error)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt("visible_page", interactiveView?.firstVisiblePage ?: 0)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroyView() {
        interactiveView = null
        super.onDestroyView()
    }

    fun previousPage() = moveBy(-1)

    fun nextPage() = moveBy(1)

    private fun moveBy(delta: Int) {
        val view = interactiveView ?: return
        if (pageCount <= 0) return
        val target = (view.firstVisiblePage + delta).coerceIn(0, pageCount - 1)
        view.scrollToPage(target)
        onPageChanged?.invoke(target, pageCount)
    }

    companion object {
        private const val ARG_URI = "document_uri"
        private const val ARG_INITIAL_PAGE = "initial_page"

        fun createArguments(uri: Uri, initialPage: Int): Bundle = bundleOf(
            ARG_URI to uri.toString(),
            ARG_INITIAL_PAGE to initialPage,
        )
    }
}
