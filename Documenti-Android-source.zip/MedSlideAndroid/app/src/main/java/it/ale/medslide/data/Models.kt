package it.ale.medslide.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "folders")
data class FolderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val color: Long,
    val sortIndex: Int,
    val updatedAt: Long,
    val deletedAt: Long? = null,
    val lastOpenedDocumentId: String? = null,
)

@Entity(
    tableName = "documents",
    foreignKeys = [
        ForeignKey(
            entity = FolderEntity::class,
            parentColumns = ["id"],
            childColumns = ["folderId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("folderId"), Index(value = ["sha256"])],
)
data class DocumentEntity(
    @PrimaryKey val id: String,
    val folderId: String,
    val displayName: String,
    val mimeType: String,
    val localPath: String,
    val sizeBytes: Long,
    val sha256: String,
    val sortIndex: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null,
    val isFavorite: Boolean = false,
    val lastPage: Int = 0,
    val remoteFileName: String? = null,
)

data class FolderWithCount(
    val id: String,
    val name: String,
    val color: Long,
    val sortIndex: Int,
    val updatedAt: Long,
    val deletedAt: Long?,
    val lastOpenedDocumentId: String?,
    val documentCount: Int,
)

enum class DocumentKind {
    PDF,
    IMAGE,
    POWERPOINT,
    WORD,
    OTHER,
}

fun DocumentEntity.kind(): DocumentKind = when {
    mimeType.equals("application/pdf", ignoreCase = true) ||
        displayName.endsWith(".pdf", ignoreCase = true) -> DocumentKind.PDF

    mimeType.startsWith("image/") -> DocumentKind.IMAGE
    mimeType.contains("presentation") ||
        displayName.endsWith(".ppt", ignoreCase = true) ||
        displayName.endsWith(".pptx", ignoreCase = true) -> DocumentKind.POWERPOINT

    mimeType.contains("word") || mimeType.contains("document") ||
        displayName.endsWith(".doc", ignoreCase = true) ||
        displayName.endsWith(".docx", ignoreCase = true) -> DocumentKind.WORD

    else -> DocumentKind.OTHER
}
