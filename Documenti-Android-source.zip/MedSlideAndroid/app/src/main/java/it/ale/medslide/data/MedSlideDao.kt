package it.ale.medslide.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface MedSlideDao {
    @Query(
        """
        SELECT f.id, f.name, f.color, f.sortIndex, f.updatedAt, f.deletedAt,
               f.lastOpenedDocumentId,
               COUNT(d.id) AS documentCount
        FROM folders f
        LEFT JOIN documents d ON d.folderId = f.id AND d.deletedAt IS NULL
        WHERE f.deletedAt IS NULL
        GROUP BY f.id
        ORDER BY f.sortIndex, f.name COLLATE NOCASE
        """,
    )
    fun observeFoldersWithCount(): Flow<List<FolderWithCount>>

    @Query("SELECT * FROM folders WHERE deletedAt IS NULL ORDER BY sortIndex, name COLLATE NOCASE")
    fun observeFolders(): Flow<List<FolderEntity>>

    @Query("SELECT * FROM documents WHERE folderId = :folderId AND deletedAt IS NULL ORDER BY sortIndex, displayName COLLATE NOCASE")
    fun observeDocuments(folderId: String): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM folders WHERE id = :id LIMIT 1")
    suspend fun getFolder(id: String): FolderEntity?

    @Query("SELECT * FROM documents WHERE id = :id LIMIT 1")
    suspend fun getDocument(id: String): DocumentEntity?

    @Query("SELECT * FROM folders ORDER BY sortIndex, name COLLATE NOCASE")
    suspend fun getAllFoldersIncludingDeleted(): List<FolderEntity>

    @Query("SELECT * FROM documents ORDER BY sortIndex, displayName COLLATE NOCASE")
    suspend fun getAllDocumentsIncludingDeleted(): List<DocumentEntity>

    @Query("SELECT * FROM documents WHERE folderId = :folderId AND deletedAt IS NULL ORDER BY sortIndex")
    suspend fun getActiveDocuments(folderId: String): List<DocumentEntity>

    @Query("SELECT COUNT(*) FROM folders WHERE deletedAt IS NULL")
    suspend fun activeFolderCount(): Int

    @Query("SELECT COUNT(*) FROM folders")
    suspend fun folderRowCount(): Int

    @Query("SELECT COALESCE(MAX(sortIndex), -1) + 1 FROM folders WHERE deletedAt IS NULL")
    suspend fun nextFolderIndex(): Int

    @Query("SELECT COALESCE(MAX(sortIndex), -1) + 1 FROM documents WHERE folderId = :folderId AND deletedAt IS NULL")
    suspend fun nextDocumentIndex(folderId: String): Int

    @Query("SELECT * FROM documents WHERE sha256 = :hash AND deletedAt IS NULL LIMIT 1")
    suspend fun findActiveDocumentByHash(hash: String): DocumentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFolder(folder: FolderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFolders(folders: List<FolderEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDocument(document: DocumentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDocuments(documents: List<DocumentEntity>)

    @Query("UPDATE folders SET name = :name, updatedAt = :updatedAt WHERE id = :id")
    suspend fun renameFolder(id: String, name: String, updatedAt: Long)

    @Query("UPDATE folders SET color = :color, updatedAt = :updatedAt WHERE id = :id")
    suspend fun recolorFolder(id: String, color: Long, updatedAt: Long)

    @Query("UPDATE folders SET lastOpenedDocumentId = :documentId WHERE id = :folderId")
    suspend fun setLastOpenedDocument(folderId: String, documentId: String?)

    @Query("UPDATE documents SET displayName = :name, updatedAt = :updatedAt WHERE id = :id")
    suspend fun renameDocument(id: String, name: String, updatedAt: Long)

    @Query("UPDATE documents SET isFavorite = :favorite, updatedAt = :updatedAt WHERE id = :id")
    suspend fun setFavorite(id: String, favorite: Boolean, updatedAt: Long)

    @Query("UPDATE documents SET lastPage = :page WHERE id = :id")
    suspend fun setLastPage(id: String, page: Int)

    @Query("UPDATE folders SET deletedAt = :timestamp, updatedAt = :timestamp WHERE id = :id")
    suspend fun markFolderDeleted(id: String, timestamp: Long)

    @Query("UPDATE documents SET deletedAt = :timestamp, updatedAt = :timestamp WHERE folderId = :folderId")
    suspend fun markDocumentsInFolderDeleted(folderId: String, timestamp: Long)

    @Query("UPDATE documents SET deletedAt = :timestamp, updatedAt = :timestamp WHERE id = :id")
    suspend fun markDocumentDeleted(id: String, timestamp: Long)

    @Transaction
    suspend fun deleteFolderWithDocuments(folderId: String, timestamp: Long) {
        markDocumentsInFolderDeleted(folderId, timestamp)
        markFolderDeleted(folderId, timestamp)
    }
}
