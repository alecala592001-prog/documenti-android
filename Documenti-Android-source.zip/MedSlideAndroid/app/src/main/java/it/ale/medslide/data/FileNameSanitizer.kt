package it.ale.medslide.data

object FileNameSanitizer {
    private val unsafe = Regex("[^\\p{L}\\p{N}._() -]")
    private val repeatedWhitespace = Regex("\\s+")

    fun sanitize(original: String): String {
        val cleaned = original
            .replace(unsafe, "_")
            .replace(repeatedWhitespace, " ")
            .trim(' ', '.')
        return cleaned.take(120).ifBlank { "documento" }
    }

    fun extensionOf(name: String): String = name.substringAfterLast('.', "")
        .lowercase()
        .take(10)

    fun withStablePrefix(id: String, name: String): String {
        val extension = extensionOf(name)
        return if (extension.isBlank()) id else "$id.$extension"
    }
}
