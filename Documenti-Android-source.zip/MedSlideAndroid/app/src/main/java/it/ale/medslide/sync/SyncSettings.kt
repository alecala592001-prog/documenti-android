package it.ale.medslide.sync

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.syncDataStore by preferencesDataStore(name = "sync_settings")

class SyncSettings(private val context: Context) {
    private val treeUriKey = stringPreferencesKey("cloud_tree_uri")

    val treeUri: Flow<Uri?> = context.syncDataStore.data.map { preferences ->
        preferences[treeUriKey]?.let(Uri::parse)
    }

    suspend fun setTreeUri(uri: Uri?) {
        context.syncDataStore.edit { preferences ->
            if (uri == null) preferences.remove(treeUriKey)
            else preferences[treeUriKey] = uri.toString()
        }
    }
}
