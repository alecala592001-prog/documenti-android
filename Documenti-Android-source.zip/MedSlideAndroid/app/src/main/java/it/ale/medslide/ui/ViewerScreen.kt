package it.ale.medslide.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.CollectionsBookmark
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Slideshow
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntSize
import androidx.core.content.FileProvider
import androidx.fragment.compose.AndroidFragment
import coil.compose.AsyncImage
import it.ale.medslide.data.DocumentEntity
import it.ale.medslide.data.DocumentKind
import it.ale.medslide.data.FolderEntity
import it.ale.medslide.data.kind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewerScreen(
    contentPadding: PaddingValues,
    folder: FolderEntity,
    documents: List<DocumentEntity>,
    currentDocument: DocumentEntity?,
    onBack: () -> Unit,
    onSelectDocument: (DocumentEntity) -> Unit,
    onImportClick: () -> Unit,
    onRenameDocument: (String, String) -> Unit,
    onDeleteDocument: (DocumentEntity) -> Unit,
    onToggleFavorite: (DocumentEntity) -> Unit,
    onPageChange: (String, Int) -> Unit,
) {
    var showDocuments by remember { mutableStateOf(false) }
    var renameDocument by remember { mutableStateOf<DocumentEntity?>(null) }
    var deleteDocument by remember { mutableStateOf<DocumentEntity?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(contentPadding),
    ) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.background,
            ),
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = "Torna alle cartelle")
                }
            },
            title = {
                Column {
                    Text(
                        folder.name,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(
                        currentDocument?.displayName
                            ?: if (documents.size == 1) "1 file" else "${documents.size} file",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            actions = {
                if (currentDocument != null) {
                    IconButton(onClick = { onToggleFavorite(currentDocument) }) {
                        Icon(
                            imageVector = if (currentDocument.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                            contentDescription = "Preferito",
                            tint = if (currentDocument.isFavorite) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                IconButton(onClick = { showDocuments = true }) {
                    Icon(Icons.Outlined.CollectionsBookmark, contentDescription = "Gestisci documenti")
                }
                IconButton(onClick = onImportClick) {
                    Icon(Icons.Outlined.Add, contentDescription = "Aggiungi documento")
                }
            },
        )

        BoxWithConstraints(Modifier.fillMaxSize()) {
            val wide = maxWidth >= 840.dp
            if (documents.isEmpty()) {
                EmptyFolder(folderName = folder.name, onImportClick = onImportClick)
            } else if (wide) {
                Row(Modifier.fillMaxSize()) {
                    DocumentRail(
                        documents = documents,
                        selected = currentDocument,
                        onSelect = onSelectDocument,
                        onImport = onImportClick,
                        modifier = Modifier.width(260.dp).fillMaxHeight(),
                    )
                    VerticalDivider(modifier = Modifier.fillMaxHeight())
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        DocumentViewer(
                            document = currentDocument,
                            onPageChange = onPageChange,
                        )
                    }
                }
            } else {
                DocumentViewer(
                    document = currentDocument,
                    onPageChange = onPageChange,
                )
            }
        }
    }

    if (showDocuments) {
        DocumentShelfSheet(
            folderName = folder.name,
            documents = documents,
            selected = currentDocument,
            onSelect = {
                onSelectDocument(it)
                showDocuments = false
            },
            onRename = {
                renameDocument = it
                showDocuments = false
            },
            onDelete = {
                deleteDocument = it
                showDocuments = false
            },
            onImport = {
                showDocuments = false
                onImportClick()
            },
            onDismiss = { showDocuments = false },
        )
    }

    renameDocument?.let { document ->
        RenameDialog(
            title = "Rinomina documento",
            initialValue = document.displayName,
            onDismiss = { renameDocument = null },
            onConfirm = {
                onRenameDocument(document.id, it)
                renameDocument = null
            },
        )
    }

    deleteDocument?.let { document ->
        AlertDialog(
            onDismissRequest = { deleteDocument = null },
            title = { Text("Eliminare il documento?") },
            text = { Text("“${document.displayName}” verrà rimosso anche dagli altri dispositivi sincronizzati.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteDocument(document)
                        deleteDocument = null
                    },
                ) { Text("Elimina", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleteDocument = null }) { Text("Annulla") } },
        )
    }
}

@Composable
private fun EmptyFolder(folderName: String, onImportClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .size(84.dp)
                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(26.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Outlined.Slideshow,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(42.dp),
            )
        }
        Spacer(Modifier.height(22.dp))
        Text("“$folderName” è vuota", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Aggiungi le slide: dalla prossima apertura verranno mostrate immediatamente.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onImportClick) {
            Icon(Icons.Outlined.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Aggiungi slide")
        }
    }
}

@Composable
private fun DocumentViewer(
    document: DocumentEntity?,
    onPageChange: (String, Int) -> Unit,
) {
    if (document == null) return
    when (document.kind()) {
        DocumentKind.PDF -> PdfViewer(document, onPageChange)
        DocumentKind.IMAGE -> ImageViewer(document)
        DocumentKind.POWERPOINT,
        DocumentKind.WORD,
        DocumentKind.OTHER -> ExternalDocumentViewer(document)
    }
}

@Composable
private fun PdfViewer(
    document: DocumentEntity,
    onPageChange: (String, Int) -> Unit,
) {
    val file = remember(document.localPath) { File(document.localPath) }
    val context = LocalContext.current
    val fragmentHolder = remember(document.id) { mutableStateOf<InteractivePdfFragment?>(null) }
    var currentPage by remember(document.id) { mutableStateOf(document.lastPage.coerceAtLeast(0)) }
    var pageCount by remember(document.id) { mutableStateOf(0) }
    var loadError by remember(document.id) { mutableStateOf(false) }

    fun bindCallbacks(fragment: InteractivePdfFragment) {
        fragment.onPageChanged = { page, count ->
            val changed = currentPage != page || pageCount != count
            currentPage = page
            pageCount = count
            if (changed) onPageChange(document.id, page)
        }
        fragment.onLoadFailed = { loadError = true }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE8ECEA)),
    ) {
        if (loadError) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Impossibile aprire questo PDF")
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = { openExternally(context, document) }) {
                        Text("Apri con un'altra app")
                    }
                }
            }
        } else {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                key(document.id) {
                    AndroidFragment<InteractivePdfFragment>(
                        modifier = Modifier.fillMaxSize(),
                        arguments = InteractivePdfFragment.createArguments(
                            uri = android.net.Uri.fromFile(file),
                            initialPage = document.lastPage,
                        ),
                        onUpdate = { fragment ->
                            fragmentHolder.value = fragment
                            bindCallbacks(fragment)
                        },
                    )
                }
            }

            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp,
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    FilledTonalButton(
                        enabled = currentPage > 0,
                        onClick = { fragmentHolder.value?.previousPage() },
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Outlined.ChevronLeft, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("Indietro")
                    }

                    Text(
                        if (pageCount > 0) "${currentPage + 1} / $pageCount" else "…",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    FilledTonalButton(
                        enabled = pageCount > 0 && currentPage < pageCount - 1,
                        onClick = { fragmentHolder.value?.nextPage() },
                        modifier = Modifier.weight(1f),
                    ) {
                        Text("Avanti")
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Outlined.ChevronRight, contentDescription = null)
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfPage(
    file: File,
    pageIndex: Int,
    isCurrentPage: Boolean,
    onZoomedChange: (Boolean) -> Unit,
) {
    val bitmap by produceState<Bitmap?>(initialValue = null, file.absolutePath, pageIndex) {
        value = withContext(Dispatchers.IO) { renderPdfPage(file, pageIndex) }
    }
    var scale by remember(file.absolutePath, pageIndex) { mutableFloatStateOf(1f) }
    var offset by remember(file.absolutePath, pageIndex) { mutableStateOf(Offset.Zero) }
    var viewportSize by remember(file.absolutePath, pageIndex) { mutableStateOf(IntSize.Zero) }

    fun resetZoom() {
        scale = 1f
        offset = Offset.Zero
        onZoomedChange(false)
    }

    LaunchedEffect(isCurrentPage) {
        if (!isCurrentPage) resetZoom()
    }

    Card(
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
    ) {
        if (bitmap == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .onSizeChanged { viewportSize = it }
                    .pointerInput(file.absolutePath, pageIndex) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            var handlingTransform = scale > 1.01f
                            var event = awaitPointerEvent()

                            do {
                                val pressedPointers = event.changes.count { it.pressed }
                                val shouldHandle = handlingTransform || scale > 1.01f || pressedPointers >= 2

                                if (shouldHandle) {
                                    handlingTransform = true
                                    val newScale = (scale * event.calculateZoom()).coerceIn(1f, 5f)
                                    val maxX = viewportSize.width * (newScale - 1f) / 2f
                                    val maxY = viewportSize.height * (newScale - 1f) / 2f
                                    val proposedOffset = if (newScale <= 1.01f) {
                                        Offset.Zero
                                    } else {
                                        offset + event.calculatePan()
                                    }

                                    scale = newScale
                                    offset = Offset(
                                        x = proposedOffset.x.coerceIn(-maxX, maxX),
                                        y = proposedOffset.y.coerceIn(-maxY, maxY),
                                    )
                                    onZoomedChange(true)
                                    event.changes.forEach { change ->
                                        if (change.positionChanged()) change.consume()
                                    }
                                }

                                event = awaitPointerEvent()
                            } while (event.changes.any { it.pressed })

                            if (scale <= 1.01f) resetZoom() else onZoomedChange(true)
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                androidx.compose.foundation.Image(
                    bitmap = bitmap!!.asImageBitmap(),
                    contentDescription = "Pagina documento",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                            clip = true
                        },
                )

                if (scale > 1.01f) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(10.dp)
                            .clickable { resetZoom() },
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.inverseSurface.copy(alpha = 0.88f),
                    ) {
                        Text(
                            text = "${(scale * 100).roundToInt()}%  Ripristina",
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            color = MaterialTheme.colorScheme.inverseOnSurface,
                            style = MaterialTheme.typography.labelMedium,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ImageViewer(document: DocumentEntity) {
    var scale by remember(document.id) { mutableFloatStateOf(1f) }
    var offset by remember(document.id) { mutableStateOf(Offset.Zero) }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF182126))
            .pointerInput(document.id) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 6f)
                    offset = if (scale <= 1.01f) Offset.Zero else offset + pan
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        AsyncImage(
            model = File(document.localPath),
            contentDescription = document.displayName,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offset.x
                    translationY = offset.y
                },
        )
    }
}

@Composable
private fun ExternalDocumentViewer(document: DocumentEntity) {
    val context = LocalContext.current
    LaunchedEffect(document.id) { openExternally(context, document) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        DocumentTypeIcon(document, Modifier.size(68.dp))
        Spacer(Modifier.height(20.dp))
        Text(
            document.displayName,
            style = MaterialTheme.typography.titleLarge,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Il documento è stato aperto nell’app compatibile installata sul dispositivo.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = { openExternally(context, document) }) {
            Icon(Icons.Outlined.OpenInNew, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Apri di nuovo")
        }
    }
}

@Composable
private fun DocumentRail(
    documents: List<DocumentEntity>,
    selected: DocumentEntity?,
    onSelect: (DocumentEntity) -> Unit,
    onImport: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface)
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Documenti", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            IconButton(onClick = onImport) { Icon(Icons.Outlined.Add, contentDescription = "Aggiungi") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(documents, key = { it.id }) { document ->
                DocumentRow(
                    document = document,
                    selected = selected?.id == document.id,
                    onClick = { onSelect(document) },
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DocumentShelfSheet(
    folderName: String,
    documents: List<DocumentEntity>,
    selected: DocumentEntity?,
    onSelect: (DocumentEntity) -> Unit,
    onRename: (DocumentEntity) -> Unit,
    onDelete: (DocumentEntity) -> Unit,
    onImport: () -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 34.dp),
        ) {
            Text(folderName, style = MaterialTheme.typography.headlineMedium)
            Text(
                "Tocca un documento per aprirlo",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth().height(360.dp),
            ) {
                items(documents, key = { it.id }) { document ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (selected?.id == document.id) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                RoundedCornerShape(16.dp),
                            )
                            .clickable { onSelect(document) }
                            .padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        DocumentTypeIcon(document, Modifier.size(32.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(document.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                readableSize(document.sizeBytes),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = { onRename(document) }) {
                            Icon(Icons.Outlined.Edit, contentDescription = "Rinomina")
                        }
                        IconButton(onClick = { onDelete(document) }) {
                            Icon(Icons.Outlined.DeleteOutline, contentDescription = "Elimina")
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Aggiungi documenti")
            }
        }
    }
}

@Composable
private fun DocumentRow(
    document: DocumentEntity,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (selected) MaterialTheme.colorScheme.primaryContainer
                else Color.Transparent,
                RoundedCornerShape(14.dp),
            )
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        DocumentTypeIcon(document, Modifier.size(30.dp))
        Spacer(Modifier.width(10.dp))
        Text(document.displayName, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun DocumentTypeIcon(document: DocumentEntity, modifier: Modifier = Modifier) {
    val icon = when (document.kind()) {
        DocumentKind.PDF -> Icons.Outlined.PictureAsPdf
        DocumentKind.IMAGE -> Icons.Outlined.Image
        DocumentKind.POWERPOINT -> Icons.Outlined.Slideshow
        DocumentKind.WORD -> Icons.Outlined.Description
        DocumentKind.OTHER -> Icons.Outlined.InsertDriveFile
    }
    val color = when (document.kind()) {
        DocumentKind.PDF -> Color(0xFFB14646)
        DocumentKind.IMAGE -> Color(0xFF397A70)
        DocumentKind.POWERPOINT -> Color(0xFFB76543)
        DocumentKind.WORD -> Color(0xFF416D9B)
        DocumentKind.OTHER -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Icon(icon, contentDescription = null, tint = color, modifier = modifier)
}

@Composable
private fun RenameDialog(
    title: String,
    initialValue: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var value by remember(initialValue) { mutableStateOf(initialValue) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
            )
        },
        confirmButton = {
            TextButton(enabled = value.isNotBlank(), onClick = { onConfirm(value.trim()) }) { Text("Salva") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

private fun pdfPageCount(file: File): Int = runCatching {
    ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
        PdfRenderer(descriptor).use { renderer -> renderer.pageCount }
    }
}.getOrDefault(0)

private fun renderPdfPage(file: File, pageIndex: Int): Bitmap? = runCatching {
    ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
        PdfRenderer(descriptor).use { renderer ->
            renderer.openPage(pageIndex).use { page ->
                val width = 1600
                val height = (width.toFloat() / page.width * page.height).toInt().coerceAtMost(2600)
                Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { bitmap ->
                    bitmap.eraseColor(AndroidColor.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                }
            }
        }
    }
}.getOrNull()

private fun openExternally(context: Context, document: DocumentEntity) {
    val file = File(document.localPath)
    if (!file.exists()) {
        Toast.makeText(context, "Il file non è disponibile offline", Toast.LENGTH_LONG).show()
        return
    }
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, document.mimeType)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        context.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(
            context,
            "Installa PowerPoint, Microsoft 365 o Google Drive per aprire questo formato",
            Toast.LENGTH_LONG,
        ).show()
    }
}

private fun readableSize(bytes: Long): String = when {
    bytes >= 1_048_576 -> "%.1f MB".format(bytes / 1_048_576.0)
    bytes >= 1_024 -> "%.0f KB".format(bytes / 1_024.0)
    else -> "$bytes B"
}
