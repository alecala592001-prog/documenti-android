package it.ale.medslide.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [FolderEntity::class, DocumentEntity::class],
    version = 1,
    exportSchema = true,
)
abstract class MedSlideDatabase : RoomDatabase() {
    abstract fun dao(): MedSlideDao

    companion object {
        @Volatile
        private var instance: MedSlideDatabase? = null

        fun get(context: Context): MedSlideDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                MedSlideDatabase::class.java,
                "medslide.db",
            ).build().also { instance = it }
        }
    }
}
