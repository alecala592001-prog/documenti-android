package it.ale.medslide.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CloudDone
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import it.ale.medslide.data.FolderWithCount

private val folderPalette = listOf(
    0xFF287F79L,
    0xFF416FA3L,
    0xFFB47B39L,
    0xFF8166ABL,
    0xFF678747L,
    0xFFAF6378L,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    folders: List<FolderWithCount>,
    syncConfigured: Boolean,
    syncState: SyncUiState,
    onFolderClick: (String) -> Unit,
    onCreateFolder: (String, Long, Boolean) -> Unit,
    onRenameFolder: (String, String) -> Unit,
    onRecolorFolder: (String, Long) -> Unit,
    onDeleteFolder: (String) -> Unit,
    onSyncClick: () -> Unit,
) {
    var search by remember { mutableStateOf("") }
    var searchVisible by remember { mutableStateOf(false) }
    var managerVisible by remember { mutableStateOf(false) }
    var createVisible by remember { mutableStateOf(false) }
    var editingFolder by remember { mutableStateOf<FolderWithCount?>(null) }
    var deletingFolder by remember { mutableStateOf<FolderWithCount?>(null) }

    val filtered = remember(folders, search) {
        if (search.isBlank()) folders else folders.filter { it.name.contains(search, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(contentPadding),
    ) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.background,
            ),
            title = {
                Text("Documenti", style = MaterialTheme.typography.displaySmall)
            },
            actions = {
                Surface(
                    onClick = {
                        searchVisible = !searchVisible
                        if (!searchVisible) search = ""
                    },
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f),
                ) {
                    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Outlined.Search,
                            contentDescription = "Cerca cartella",
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }
                Spacer(Modifier.width(10.dp))
                Surface(
                    onClick = { managerVisible = true },
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary,
                    shadowElevation = 2.dp,
                ) {
                    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Outlined.Add,
                            contentDescription = "Gestisci cartelle",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(25.dp),
                        )
                    }
                }
                Spacer(Modifier.width(16.dp))
            },
        )

        AnimatedVisibility(visible = searchVisible) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 14.dp),
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                placeholder = { Text("Cerca cartella") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f),
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.24f),
                ),
            )
        }

        if (filtered.isEmpty()) {
            EmptyHome(searching = search.isNotBlank())
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 160.dp),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 28.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                gridItems(filtered, key = { it.id }) { folder ->
                    FolderCard(
                        folder = folder,
                        onClick = { onFolderClick(folder.id) },
                    )
                }
            }
        }
    }

    if (managerVisible) {
        FolderManagerDialog(
            folders = folders,
            syncConfigured = syncConfigured,
            syncState = syncState,
            onDismiss = { managerVisible = false },
            onCreate = {
                managerVisible = false
                createVisible = true
            },
            onEdit = {
                managerVisible = false
                editingFolder = it
            },
            onDelete = {
                managerVisible = false
                deletingFolder = it
            },
            onSyncClick = {
                managerVisible = false
                onSyncClick()
            },
        )
    }

    if (createVisible) {
        FolderEditDialog(
            title = "Nuova cartella",
            initialName = "",
            initialColor = folderPalette.first(),
            confirmLabel = "Crea",
            onDismiss = { createVisible = false },
            onConfirm = { name, color ->
                onCreateFolder(name, color, false)
                createVisible = false
            },
        )
    }

    editingFolder?.let { folder ->
        FolderEditDialog(
            title = "Modifica cartella",
            initialName = folder.name,
            initialColor = folder.color,
            confirmLabel = "Salva",
            onDismiss = { editingFolder = null },
            onConfirm = { name, color ->
                onRenameFolder(folder.id, name)
                onRecolorFolder(folder.id, color)
                editingFolder = null
            },
        )
    }

    deletingFolder?.let { folder ->
        AlertDialog(
            onDismissRequest = { deletingFolder = null },
            title = { Text("Eliminare “${folder.name}”?") },
            text = { Text("La cartella e i documenti contenuti verranno rimossi anche dagli altri dispositivi sincronizzati.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteFolder(folder.id)
                        deletingFolder = null
                    },
                ) { Text("Elimina", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deletingFolder = null }) { Text("Annulla") } },
        )
    }
}

@Composable
private fun FolderCard(
    folder: FolderWithCount,
    onClick: () -> Unit,
) {
    val folderColor = Color(folder.color)
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, folderColor.copy(alpha = 0.16f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp, pressedElevation = 1.dp),
        modifier = Modifier.heightIn(min = 192.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(folderColor.copy(alpha = 0.23f), folderColor.copy(alpha = 0.04f)),
                    ),
                ),
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp),
            ) {
                ElegantFolderIcon(folderColor)
                Spacer(Modifier.height(18.dp))
                Text(
                    folder.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(6.dp))
                Surface(
                    shape = CircleShape,
                    color = folderColor.copy(alpha = 0.12f),
                ) {
                    Text(
                        if (folder.documentCount == 1) "1 documento" else "${folder.documentCount} documenti",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun ElegantFolderIcon(folderColor: Color) {
    Box(
        modifier = Modifier
            .width(80.dp)
            .height(60.dp),
    ) {
        Box(
            modifier = Modifier
                .width(34.dp)
                .height(18.dp)
                .background(
                    folderColor.copy(alpha = 0.72f),
                    RoundedCornerShape(topStart = 11.dp, topEnd = 11.dp),
                ),
        )
        Box(
            modifier = Modifier
                .width(62.dp)
                .height(39.dp)
                .align(Alignment.BottomCenter)
                .offset(y = (-9).dp)
                .rotate(-5f)
                .background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(6.dp)),
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(47.dp)
                .align(Alignment.BottomStart)
                .shadow(5.dp, RoundedCornerShape(14.dp))
                .background(
                    Brush.linearGradient(listOf(folderColor, folderColor.copy(alpha = 0.78f))),
                    RoundedCornerShape(14.dp),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Outlined.Description,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.94f),
                modifier = Modifier.size(25.dp),
            )
        }
    }
}

@Composable
private fun EmptyHome(searching: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            if (searching) "Nessuna cartella trovata" else "Tocca + per creare una cartella",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun FolderManagerDialog(
    folders: List<FolderWithCount>,
    syncConfigured: Boolean,
    syncState: SyncUiState,
    onDismiss: () -> Unit,
    onCreate: () -> Unit,
    onEdit: (FolderWithCount) -> Unit,
    onDelete: (FolderWithCount) -> Unit,
    onSyncClick: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cartelle") },
        text = {
            Column {
                Surface(
                    onClick = onCreate,
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Outlined.Add, contentDescription = null)
                        Spacer(Modifier.width(12.dp))
                        Text("Aggiungi cartella", style = MaterialTheme.typography.titleMedium)
                    }
                }

                if (folders.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    LazyColumn(modifier = Modifier.heightIn(max = 290.dp)) {
                        items(folders, key = { it.id }) { folder ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    Icons.Outlined.Folder,
                                    contentDescription = null,
                                    tint = Color(folder.color),
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    folder.name,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                IconButton(onClick = { onEdit(folder) }) {
                                    Icon(Icons.Outlined.Edit, contentDescription = "Modifica ${folder.name}")
                                }
                                IconButton(onClick = { onDelete(folder) }) {
                                    Icon(Icons.Outlined.DeleteOutline, contentDescription = "Elimina ${folder.name}")
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(onClick = onSyncClick)
                        .padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = if (syncConfigured) Icons.Outlined.CloudDone else Icons.Outlined.CloudOff,
                        contentDescription = null,
                        tint = when (syncState) {
                            SyncUiState.Running -> MaterialTheme.colorScheme.secondary
                            is SyncUiState.Failed -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.primary
                        },
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Sincronizzazione", style = MaterialTheme.typography.titleMedium)
                        Text(
                            when {
                                syncState == SyncUiState.Running -> "In corso…"
                                syncConfigured -> "Telefono e tablet collegati"
                                else -> "Configura una sola volta"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Chiudi") } },
    )
}

@Composable
private fun FolderEditDialog(
    title: String,
    initialName: String,
    initialColor: Long,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String, Long) -> Unit,
) {
    var name by remember(initialName) { mutableStateOf(initialName) }
    var color by remember(initialColor) { mutableStateOf(initialColor) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    folderPalette.forEach { option ->
                        Box(
                            modifier = Modifier
                                .size(if (color == option) 34.dp else 30.dp)
                                .clip(CircleShape)
                                .background(Color(option))
                                .clickable { color = option },
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = { onConfirm(name.trim(), color) },
            ) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}
