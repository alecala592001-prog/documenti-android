package it.ale.medslide.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.StateFlow

private val supportedTypes = arrayOf(
    "application/pdf",
    "application/vnd.ms-powerpoint",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "image/*",
)

@Composable
fun MedSlideRoot(
    incomingUris: StateFlow<List<Uri>>,
    onIncomingUrisConsumed: () -> Unit,
) {
    val context = LocalContext.current
    val application = context.applicationContext as Application
    val viewModel: MainViewModel = viewModel(factory = MainViewModel.Factory(application))

    val folders by viewModel.folders.collectAsStateWithLifecycle()
    val folderEntities by viewModel.folderEntities.collectAsStateWithLifecycle()
    val currentFolder by viewModel.currentFolder.collectAsStateWithLifecycle()
    val documents by viewModel.documents.collectAsStateWithLifecycle()
    val currentDocument by viewModel.currentDocument.collectAsStateWithLifecycle()
    val pendingImports by viewModel.pendingImports.collectAsStateWithLifecycle()
    val syncTreeUri by viewModel.syncTreeUri.collectAsStateWithLifecycle()
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()
    val sharedUris by incomingUris.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var showSyncSheet by remember { mutableStateOf(false) }
    var directImportFolderId by remember { mutableStateOf<String?>(null) }

    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments(),
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.queueImports(uris)
            directImportFolderId?.let(viewModel::importPendingInto)
        }
        directImportFolderId = null
    }

    val syncFolderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree(),
    ) { uri ->
        uri?.let {
            viewModel.setSyncFolder(
                it,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
        }
    }

    LaunchedEffect(sharedUris) {
        if (sharedUris.isNotEmpty()) {
            viewModel.queueImports(sharedUris)
            onIncomingUrisConsumed()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.messages.collect { message -> snackbarHostState.showSnackbar(message) }
    }

    BackHandler(enabled = currentFolder != null) { viewModel.closeFolder() }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { contentPadding ->
        if (currentFolder == null) {
            HomeScreen(
                contentPadding = contentPadding,
                folders = folders,
                syncConfigured = syncTreeUri != null,
                syncState = syncState,
                onFolderClick = viewModel::openFolder,
                onCreateFolder = viewModel::createFolder,
                onRenameFolder = viewModel::renameFolder,
                onRecolorFolder = viewModel::recolorFolder,
                onDeleteFolder = viewModel::deleteFolder,
                onSyncClick = { showSyncSheet = true },
            )
        } else {
            ViewerScreen(
                contentPadding = contentPadding,
                folder = currentFolder!!,
                documents = documents,
                currentDocument = currentDocument,
                onBack = viewModel::closeFolder,
                onSelectDocument = viewModel::selectDocument,
                onImportClick = {
                    directImportFolderId = currentFolder!!.id
                    filePicker.launch(supportedTypes)
                },
                onRenameDocument = viewModel::renameDocument,
                onDeleteDocument = viewModel::deleteDocument,
                onToggleFavorite = viewModel::toggleFavorite,
                onPageChange = viewModel::rememberPage,
            )
        }
    }

    if (pendingImports.isNotEmpty() && directImportFolderId == null) {
        ImportDestinationDialog(
            fileCount = pendingImports.size,
            folders = folderEntities,
            onFolderSelected = viewModel::importPendingInto,
            onDismiss = viewModel::clearPendingImports,
        )
    }

    if (showSyncSheet) {
        SyncSheet(
            configured = syncTreeUri != null,
            state = syncState,
            onChooseFolder = { syncFolderPicker.launch(null) },
            onSyncNow = viewModel::syncNow,
            onDisconnect = viewModel::disconnectSync,
            onDismiss = { showSyncSheet = false },
        )
    }
}
