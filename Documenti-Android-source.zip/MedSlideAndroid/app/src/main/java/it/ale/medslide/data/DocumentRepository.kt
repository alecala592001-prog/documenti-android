package it.ale.medslide.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID

data class ImportResult(
    val imported: List<DocumentEntity>,
    val duplicates: List<DocumentEntity>,
    val failedNames: List<String>,
)

class DocumentRepository(
    private val context: Context,
    private val dao: MedSlideDao,
) {
    val foldersWithCount: Flow<List<FolderWithCount>> = dao.observeFoldersWithCount()
    val folders: Flow<List<FolderEntity>> = dao.observeFolders()

    fun documents(folderId: String): Flow<List<DocumentEntity>> = dao.observeDocuments(folderId)

    suspend fun ensureDefaultFolders() {
        if (dao.folderRowCount() > 0) return
        // A deterministic, old timestamp lets a renamed folder from another device
        // win during the first synchronization on a newly installed device.
        val initialTimestamp = 1L
        dao.upsertFolders(
            listOf(
                FolderEntity(
                    id = "default-medical-approval",
                    name = "Approvazione medico",
                    color = 0xFF2D716CL,
                    sortIndex = 0,
                    updatedAt = initialTimestamp,
                ),
                FolderEntity(
                    id = "default-third-display",
                    name = "Terzo espositore",
                    color = 0xFF315C78L,
                    sortIndex = 1,
                    updatedAt = initialTimestamp,
                ),
                FolderEntity(
                    id = "default-archive",
                    name = "Archivio",
                    color = 0xFF8A6A4AL,
                    sortIndex = 2,
                    updatedAt = initialTimestamp,
                ),
            ),
        )
    }

    suspend fun createFolder(name: String, color: Long): FolderEntity {
        val now = System.currentTimeMillis()
        val folder = FolderEntity(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifBlank { "Nuova cartella" },
            color = color,
            sortIndex = dao.nextFolderIndex(),
            updatedAt = now,
        )
        dao.upsertFolder(folder)
        return folder
    }

    suspend fun renameFolder(id: String, newName: String) {
        val name = newName.trim()
        if (name.isNotEmpty()) dao.renameFolder(id, name, System.currentTimeMillis())
    }

    suspend fun recolorFolder(id: String, color: Long) {
        dao.recolorFolder(id, color, System.currentTimeMillis())
    }

    suspend fun deleteFolder(id: String) {
        dao.deleteFolderWithDocuments(id, System.currentTimeMillis())
    }

    suspend fun importUris(folderId: String, uris: List<Uri>): ImportResult = withContext(Dispatchers.IO) {
        val imported = mutableListOf<DocumentEntity>()
        val duplicates = mutableListOf<DocumentEntity>()
        val failed = mutableListOf<String>()
        var nextIndex = dao.nextDocumentIndex(folderId)

        uris.distinct().forEach { uri ->
            val metadata = metadata(uri)
            val displayName = metadata.first
            try {
                val documentId = UUID.randomUUID().toString()
                val safeName = FileNameSanitizer.sanitize(displayName)
                val extension = FileNameSanitizer.extensionOf(safeName)
                val destinationDir = File(context.filesDir, "documents").apply { mkdirs() }
                val destination = File(
                    destinationDir,
                    if (extension.isBlank()) documentId else "$documentId.$extension",
                )

                val digest = MessageDigest.getInstance("SHA-256")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(destination).use { output ->
                        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            digest.update(buffer, 0, read)
                            output.write(buffer, 0, read)
                        }
                    }
                } ?: error("Il file non è leggibile")

                val hash = digest.digest().joinToString("") { "%02x".format(it) }
                val duplicate = dao.findActiveDocumentByHash(hash)
                if (duplicate != null) {
                    destination.delete()
                    duplicates += duplicate
                } else {
                    val now = System.currentTimeMillis()
                    val mime = context.contentResolver.getType(uri)
                        ?: mimeFromExtension(extension)
                        ?: "application/octet-stream"
                    val document = DocumentEntity(
                        id = documentId,
                        folderId = folderId,
                        displayName = safeName,
                        mimeType = mime,
                        localPath = destination.absolutePath,
                        sizeBytes = destination.length(),
                        sha256 = hash,
                        sortIndex = nextIndex++,
                        createdAt = now,
                        updatedAt = now,
                        remoteFileName = FileNameSanitizer.withStablePrefix(documentId, safeName),
                    )
                    dao.upsertDocument(document)
                    imported += document
                }
            } catch (_: Exception) {
                failed += displayName
            }
        }

        ImportResult(imported, duplicates, failed)
    }

    suspend fun getFolder(id: String): FolderEntity? = dao.getFolder(id)
    suspend fun getDocument(id: String): DocumentEntity? = dao.getDocument(id)
    suspend fun activeDocuments(folderId: String): List<DocumentEntity> = dao.getActiveDocuments(folderId)

    suspend fun rememberOpened(folderId: String, documentId: String) {
        dao.setLastOpenedDocument(folderId, documentId)
    }

    suspend fun renameDocument(id: String, name: String) {
        val safeName = FileNameSanitizer.sanitize(name)
        if (safeName.isNotBlank()) dao.renameDocument(id, safeName, System.currentTimeMillis())
    }

    suspend fun toggleFavorite(document: DocumentEntity) {
        dao.setFavorite(document.id, !document.isFavorite, System.currentTimeMillis())
    }

    suspend fun rememberPage(documentId: String, page: Int) {
        dao.setLastPage(documentId, page.coerceAtLeast(0))
    }

    suspend fun deleteDocument(id: String) {
        dao.markDocumentDeleted(id, System.currentTimeMillis())
    }

    private fun metadata(uri: Uri): Pair<String, Long> {
        var name: String? = null
        var size = 0L
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null,
            null,
            null,
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex)
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        return (name ?: uri.lastPathSegment ?: "documento") to size
    }

    private fun mimeFromExtension(extension: String): String? = when (extension.lowercase()) {
        "pdf" -> "application/pdf"
        "ppt" -> "application/vnd.ms-powerpoint"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        "doc" -> "application/msword"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        else -> null
    }

    companion object {
        fun sha256(file: File): String {
            val digest = MessageDigest.getInstance("SHA-256")
            FileInputStream(file).use { input ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    digest.update(buffer, 0, read)
                }
            }
            return digest.digest().joinToString("") { "%02x".format(it) }
        }
    }
}
