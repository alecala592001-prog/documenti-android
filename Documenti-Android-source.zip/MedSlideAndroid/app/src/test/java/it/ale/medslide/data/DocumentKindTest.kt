package it.ale.medslide.data

import org.junit.Assert.assertEquals
import org.junit.Test

class DocumentKindTest {
    private fun document(name: String, mime: String) = DocumentEntity(
        id = "id",
        folderId = "folder",
        displayName = name,
        mimeType = mime,
        localPath = "/tmp/$name",
        sizeBytes = 1,
        sha256 = "hash",
        sortIndex = 0,
        createdAt = 0,
        updatedAt = 0,
    )

    @Test
    fun recognizesPowerPointFromExtension() {
        assertEquals(DocumentKind.POWERPOINT, document("deck.pptx", "application/octet-stream").kind())
    }

    @Test
    fun recognizesPdfFromMimeType() {
        assertEquals(DocumentKind.PDF, document("file", "application/pdf").kind())
    }
}
