package it.ale.medslide.data

import org.junit.Assert.assertEquals
import org.junit.Test

class FileNameSanitizerTest {
    @Test
    fun removesUnsafeCharactersAndPreservesExtension() {
        assertEquals("Referto_medico finale.pdf", FileNameSanitizer.sanitize("Referto:medico  finale.pdf"))
    }

    @Test
    fun createsStableCloudName() {
        assertEquals("abc-123.pptx", FileNameSanitizer.withStablePrefix("abc-123", "Presentazione.pptx"))
    }

    @Test
    fun providesFallbackForBlankNames() {
        assertEquals("documento", FileNameSanitizer.sanitize("..."))
    }
}
