package it.ale.medslide

import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.view.View
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import it.ale.medslide.data.DocumentEntity
import it.ale.medslide.data.FolderEntity
import it.ale.medslide.ui.InteractivePdfFragment
import it.ale.medslide.ui.ViewerScreen
import it.ale.medslide.ui.theme.MedSlideTheme
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PdfCrashRegressionTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    @Test fun opensPdfNavigatesAndRecreatesActivity() {
        val activity = compose.activity
        val file = File(activity.filesDir, "crash-regression.pdf")
        PdfDocument().use { pdf ->
            repeat(3) { index ->
                val page = pdf.startPage(PdfDocument.PageInfo.Builder(600, 800, index + 1).create())
                page.canvas.drawText("Slide ${index + 1}: testo selezionabile", 40f, 100f,
                    Paint().apply { textSize = 24f })
                pdf.finishPage(page)
            }
            file.outputStream().use(pdf::writeTo)
        }
        val selectedPage = AtomicInteger(-1)
        val document = DocumentEntity("test-pdf", "test-folder", "Prova.pdf", "application/pdf",
            file.absolutePath, file.length(), "test", 0, 0, 0)
        compose.runOnUiThread {
            activity.setContent {
                MedSlideTheme {
                    ViewerScreen(PaddingValues(), FolderEntity("test-folder", "Prova", 0, 0, 0),
                        listOf(document), document, {}, {}, {}, { _, _ -> }, {}, {},
                        { _, page -> selectedPage.set(page) })
                }
            }
        }
        // In 1.3 this crashes the app before the first page count is reported.
        compose.waitUntil(60_000) { selectedPage.get() == 0 }
        compose.onNodeWithText("Avanti").performClick()
        compose.waitUntil(15_000) { selectedPage.get() == 1 }
        compose.onNodeWithText("Indietro").performClick()
        compose.waitUntil(15_000) { selectedPage.get() == 0 }
        compose.activityRule.scenario.recreate()
        compose.waitForIdle()
        compose.activityRule.scenario.onActivity {
            assertTrue("Restarts without restoring an orphan PDF fragment",
                it.supportFragmentManager.fragments.none { fragment -> fragment is InteractivePdfFragment })
            assertTrue(file.exists())
        }
    }
}
