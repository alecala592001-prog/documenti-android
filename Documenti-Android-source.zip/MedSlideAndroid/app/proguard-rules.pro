# MedSlide keeps its release configuration intentionally small.
