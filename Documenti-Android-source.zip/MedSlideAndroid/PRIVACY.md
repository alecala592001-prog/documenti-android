# Privacy di Documenti

Documenti non contiene pubblicità, analytics o tracker. Non legge la posta elettronica e non richiede accesso generale alla memoria.

- Gli allegati vengono ricevuti soltanto quando l’utente seleziona “Condividi con Documenti” o li sceglie manualmente.
- I file locali sono conservati nello spazio privato dell’app.
- La sincronizzazione usa unicamente la cartella selezionata dall’utente tramite il selettore Android.
- Il contenuto non viene inviato a servizi di intelligenza artificiale o convertitori online.
- Disinstallando l’app vengono rimossi i file locali; le copie presenti nella cartella cloud scelta restano disponibili per il ripristino.
